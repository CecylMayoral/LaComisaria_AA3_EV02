
package com.LaComisaria.pedido.service;

import com.LaComisaria.pedido.model.turnos;
import com.LaComisaria.pedido.repository.turnoRepository;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class turnoServiceImplement implements turnoService{
    
    @Autowired
    private turnoRepository turnoRepository;

    @Override
    public turnos Newturno(turnos Newturno) {
        return turnoRepository.save(Newturno);
    }

    @Override
    public Iterable<turnos> getAll() {
        return this.turnoRepository.findAll(); 
    }

    @Override
    public turnos modifyturnos(turnos turnos) {
        Optional<turnos> turnoEncontrado = this.turnoRepository.findById(turnos.getIdTurno());
        if (turnoEncontrado.get()!= null) {
            turnoEncontrado.get().setTurnoDisponible(turnos.getTurnoDisponible());
            return this.Newturno(turnoEncontrado.get());
    }
        return null;
    }

    @Override
    public Boolean deleteturnos(Integer idTurno) {
        this.turnoRepository.deleteById(idTurno);
        return true;
    }
    
}
