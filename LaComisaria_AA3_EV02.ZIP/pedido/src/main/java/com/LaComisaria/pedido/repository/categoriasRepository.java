
package com.LaComisaria.pedido.repository;

// Importación de la clase "categoria" del paquete "com.LaComisaria.pedido.model"
import com.LaComisaria.pedido.model.categorias;

// Importación de la interfaz JpaRepository de Spring Data JPA
import org.springframework.data.jpa.repository.JpaRepository;

// Definición de la interfaz "categoriaRepository" que extiende JpaRepository
public interface categoriasRepository extends JpaRepository<categorias, Integer>{
    
}
