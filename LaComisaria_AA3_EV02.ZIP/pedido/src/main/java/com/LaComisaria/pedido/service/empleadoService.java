
package com.LaComisaria.pedido.service;

import com.LaComisaria.pedido.model.empleado;

public interface empleadoService {
    empleado Newempleado(empleado Newempleado);
    Iterable<empleado> getAll();
    empleado modifyempleado (empleado empleado);
    Boolean deleteempleado (Integer idempleado);
}
