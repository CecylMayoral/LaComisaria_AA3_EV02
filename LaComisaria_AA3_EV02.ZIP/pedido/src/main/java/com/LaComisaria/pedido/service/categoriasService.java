
package com.LaComisaria.pedido.service;

// Importa la clase categorias desde el paquete model
import com.LaComisaria.pedido.model.categorias;

// Definición de la interfaz categoriasService
public interface categoriasService {
    
     /**Crea una nueva instancia de categorias.
     * @param Newcategorias una instancia de categoria que se va a crear.
     * @return la instancia de categoria creada.*/
    categorias Newcategorias (categorias Newcategorias);
    
    /**Obtiene todas las instancias de categoria almacenadas.
     * @return un Iterable que contiene todas las instancias de categoria.*/
    Iterable<categorias> getAll();
    
     /**Modifica una instancia existente de categoria.
     * @param categorias una instancia de categoria que se va a modificar.
     * @return la instancia de categoria modificada.*/
    categorias modifycategorias (categorias categorias);
    
    /**Elimina una instancia de categoria basada en su identificador.
     * @param idCategoria el identificador de la instancia de categoria que se va a eliminar.
     * @return un valor booleano que indica si la operación de eliminación fue exitosa.*/
    Boolean deletecategorias (Integer idCategoria);
}
