
package com.LaComisaria.pedido.controller;

import com.LaComisaria.pedido.model.producto;
import com.LaComisaria.pedido.service.productoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/producto")
public class productoController {
    
    @Autowired
    private productoService productoService;
    
    @PostMapping("/nuevo")
    public producto Newproducto (@RequestBody producto Newproducto) {
        return this.productoService.Newproducto(Newproducto);
    }
    
    @GetMapping("/mostrar")
    public Iterable<producto> getAll() {
        return productoService.getAll();
    } 
    
    @PostMapping("/modificar")
    public producto updateProducto(@RequestBody producto producto){
        return this.productoService.modifyproducto(producto);
    }
    
    @PostMapping(value = "/{id}")
    public Boolean deleteProduct(@PathVariable(value="id") Integer id) {
        return this.productoService.deleteproducto(id);
    }
}
