
package com.LaComisaria.pedido.service;

import com.LaComisaria.pedido.model.asistencia;

public interface asistenciaService {
    /**Crea una nueva instancia de categorias.
     * @param Newasistencia una instancia de categoria que se va a crear.
     * @return la instancia de categoria creada.*/
    asistencia Newasistencia (asistencia Newasistencia);
    
    /**Obtiene todas las instancias de categoria almacenadas.
     * @return un Iterable que contiene todas las instancias de categoria.*/
    Iterable<asistencia> getAll();
    
     /**Modifica una instancia existente de categoria.
     * @param asistencia una instancia de categoria que se va a modificar.
     * @return la instancia de categoria modificada.*/
    asistencia modifyasistencia (asistencia asistencia);
    
    /**Elimina una instancia de categoria basada en su identificador.
     * @param idAsistencia el identificador de la instancia de categoria que se va a eliminar.
     * @return un valor booleano que indica si la operación de eliminación fue exitosa.*/
    Boolean deleteasistencia (Integer idAsistencia);
    
}
