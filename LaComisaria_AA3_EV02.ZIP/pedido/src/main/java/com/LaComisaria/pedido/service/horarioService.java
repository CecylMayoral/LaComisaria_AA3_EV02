
package com.LaComisaria.pedido.service;

import com.LaComisaria.pedido.model.horario;

public interface horarioService {
    
    horario NewHorarios (horario NewHorarios);
    
    Iterable<horario> getAll();
    
    horario modifyHorario (horario horario);
    
    Boolean deleteHorario (Integer idHorario);
    
}
