
package com.LaComisaria.pedido.service;

import com.LaComisaria.pedido.model.producto;

public interface productoService {
    producto Newproducto (producto Newproducto);
    Iterable<producto> getAll();
    producto modifyproducto (producto producto);
    Boolean deleteproducto (Integer id_producto);
}
