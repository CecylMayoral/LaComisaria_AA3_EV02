
package com.LaComisaria.pedido.service;

// Importaciones necesarias
import com.LaComisaria.pedido.model.categorias;
import com.LaComisaria.pedido.repository.categoriasRepository;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

// La anotación @Service indica que esta clase es un servicio de Spring y puede ser inyectado en otros componentes
@Service
public class categoriasServiceImplement implements categoriasService {
    
    // La anotación @Autowired permite la inyección automática del repositorio de categorías
    @Autowired
    private categoriasRepository categoriasRepository;
    
    // Implementación del método para crear una nueva categoría
    @Override
    public categorias Newcategorias(categorias Newcategorias) {
        
        // Guarda la nueva categoría en la base de datos y la devuelve
        return categoriasRepository.save(Newcategorias);
    }

     // Implementación del método para obtener todas las categorías
    @Override
    public Iterable<categorias> getAll() {
        
        // Devuelve todas las categorías encontradas en la base de datos
        return this.categoriasRepository.findAll();
    }

    // Implementación del método para modificar una categoría existente
    @Override
    public categorias modifycategorias(categorias categorias) {
        
        // Busca la categoría en la base de datos por su ID
        Optional<categorias> categoriasEncontrado = this.categoriasRepository.findById(categorias.getIdCategoria());
        
         // Si la categoría existe, se actualizan sus datos
        if (categoriasEncontrado.get()!= null) {
            
            // Actualiza el nombre y la descripción de la categoría encontrada
            categoriasEncontrado.get().setNombre(categorias.getNombre());
            categoriasEncontrado.get().setDescripcion(categorias.getDescripcion());
            
            // Guarda los cambios y devuelve la categoría actualizada
            return this.Newcategorias(categoriasEncontrado.get());
    }
        // Si la categoría no existe, devuelve null
        return null;
    }

    // Implementación del método para eliminar una categoría por su ID
    @Override
    public Boolean deletecategorias(Integer idCategoria) {
        
        // Elimina la categoría de la base de datos por su ID
        this.categoriasRepository.deleteById(idCategoria);
        
        // Devuelve true indicando que la operación fue exitosa       
        return true;
    }
    
}
