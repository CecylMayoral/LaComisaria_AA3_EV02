
package com.LaComisaria.pedido.controller;

import com.LaComisaria.pedido.model.turnoEmpleado;
import com.LaComisaria.pedido.service.turnoEmpleadoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
    
    @RequestMapping("/TurnoEmpleado")
public class turnoEmpleadoController {
    
   @Autowired
   private turnoEmpleadoService turnoEmpleadoService;
   
   @PostMapping("/nuevo")
   public turnoEmpleado NewTurnoEmpleado (@RequestBody turnoEmpleado NewTurnoEmpleado ) {
       return this.turnoEmpleadoService.NewTurnoEmpleado(NewTurnoEmpleado);
   }
   
   @GetMapping("/mostrar")
   public Iterable<turnoEmpleado> getAll() {
       return turnoEmpleadoService.getAll();
   }
   
   @PostMapping("/modificar")
   public turnoEmpleado UpdateTurnoEmpleado (@RequestBody turnoEmpleado turnoEmpleado) {
       return this.turnoEmpleadoService.modifyTurnoEmpleado(turnoEmpleado);
   }
   
   @PostMapping(value = "/{id}")
   public Boolean deleteTurnoEmpleado (@PathVariable(value = "id")Integer id) {
       return this.turnoEmpleadoService.deleteTurnoEmpleado(id);
   }
    
}
